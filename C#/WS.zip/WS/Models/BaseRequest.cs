﻿using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Comments.Models
{
    public class BaseRequest
    {
        public BaseRequest() 
        {
        }

        public BaseRequest(int errorID, string text, string content)
        {
            ErrorID = errorID;
            ErrorText = text;
            Content = content;
        }

        [Required]
        public int ErrorID { get; set; }

        [Required]
        public string ErrorText { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Input is too long! This was validated on the server.")]
        public string Content { get; set; }

    }
}