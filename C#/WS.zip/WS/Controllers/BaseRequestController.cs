﻿using Comments.Models;
using Eisk.BusinessEntities;
using Eisk.BusinessLogicLayer;
using Eisk.DataAccessLayer;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;


namespace WS.Controllers
{
    public class BaseRequestController : ApiController
    {
        // GET api/values
        public IEnumerable<object> Get(BaseRequest baseRequest)
        {
            return new CityBLL().GetAllCities();
                //.Select(
                //instance =>
                //    new
                //    {
                //        instance.BaseRequestID,
                //        instance.BaseRequestName,
                //        OrganismsCount = instance.Organisms.Count(),
                //        UsersCount = instance.BaseRequest_Users.Count(),
                //        ProjectsCount = instance.BaseRequest_Projects.Count()
                //    }
                //); 
        }

        // GET api/values/5
        public object Get(int id)
        {
            return new object();
        }

        // POST api/values
        public object Post([FromBody]BaseRequest value)
        {
            return new CityBLL().GetAllCities();
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]BaseRequest value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}