﻿using Eisk.BusinessEntities;
using Eisk.BusinessLogicLayer;
using Eisk.DataAccessLayer;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;


namespace WS.Controllers
{
    public class GroupController : ApiController
    {
        // GET api/values
        public IEnumerable<Group> Get()
        {
            return new GroupBLL().GetAllGroups();
                //.Select(
                //instance =>
                //    new
                //    {
                //        instance.GroupID,
                //        instance.GroupName,
                //        OrganismsCount = instance.Organisms.Count(),
                //        UsersCount = instance.Group_Users.Count(),
                //        ProjectsCount = instance.Group_Projects.Count()
                //    }
                //); 
        }

        // GET api/values/5
        public object Get(int id)
        {
            return new GroupBLL().GetAllGroups().Where(instance => instance.GroupID == id).Select(
                instance =>
                    new
                    {
                        instance.GroupID,
                        instance.GroupName,
                        OrganismsCount = instance.Organisms.Count(),
                        UsersCount = instance.Group_Users.Count(),
                        ProjectsCount = instance.Group_Projects.Count()
                    }
                );
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}