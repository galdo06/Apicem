﻿using System.Json;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Comments.Web.Filters
{
    public class ValidationActionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext context)
        {
            var modelState = context.ModelState;
            if (!modelState.IsValid)
            {
                JsonValue errors = new JsonObject();
                foreach (var key in modelState.Keys)
                {
                    var state = modelState[key];
                    if (state.Errors.Any())
                    {
                        errors[key] = state.Errors.First().ErrorMessage;
                    }
                }
                context.Response = context.Request.CreateResponse<JsonValue>(
                     HttpStatusCode.BadRequest,errors);
            }
        }
    }

    public interface IKeyValueProvider
    {
        string GetValue(string key);
    }

    class RequestFormKeyValueProvider : IKeyValueProvider
    {
        public string GetValue(string key)
        {
            return HttpContext.Current.Request.Form[key];
        }
    }
}