﻿using System.Json;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Comments.Web.Filters
{
    public class AuthorizeTokenAttribute : AuthorizationFilterAttribute
    {
        private const string TOKEN_HEADER = "Authorization";

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if (actionContext != null)
            {
                if (!AuthorizeRequest(actionContext.ControllerContext.Request))
                {
                    actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized) { RequestMessage = actionContext.ControllerContext.Request };
                }
                return;
            }
        }

        private bool AuthorizeRequest(System.Net.Http.HttpRequestMessage request)
        {
            bool authorized = false;
            if (request.Headers.Contains(TOKEN_HEADER))
            {
                var tokenValue = request.Headers.GetValues(TOKEN_HEADER);
                if (tokenValue.Count() == 1)
                {
                    var value = tokenValue.FirstOrDefault();
                    //Token validation logic here
                    //set authorized variable accordingly
                }
            }
            return authorized;
        }
    }
}