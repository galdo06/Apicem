﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WS.Models;

namespace WS.Controllers
{
    public class ProductsController : ApiController
    {
        public object Get([FromBody]Product product)
        {
            if (ModelState.IsValid)
            {
                // Do something with the product (not shown). 

                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }

        public HttpResponseMessage Post([FromBody]Product product)
        {
            if (product != null)
            {
                // Do something with the product (not shown). 

                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }
    }
}